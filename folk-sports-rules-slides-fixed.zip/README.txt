扯鈴與民俗運動規則簡報

開啟方式
1. 先將 folk-sports-rules-slides-fixed.zip 下載到電腦。
2. 在 Windows 檔案總管中按右鍵，選「全部解壓縮」。
3. 開啟解壓縮後的資料夾，再用 Edge 或 Chrome 開啟 index.html。
4. 請保留 index.html 和四個簡報 HTML 在同一個資料夾內。

版本說明（2026-11-16）
- index.html 已把扯鈴、跳繩、陀螺、踢毽四份簡報整合成同一頁：點卡片或上方標籤切換運動，用「上一頁／下一頁」、頁碼選單或鍵盤左右鍵換頁。
- 切換運動與換頁都在同一份文件內完成，不再以連結開啟其他 HTML，因此在 ChatGPT 等單檔 HTML 預覽視窗、沙箱 iframe 或本機檔案模式下都不會出現「這項內容已遭到封鎖」的空白頁。
- 若瀏覽器停用 JavaScript，index.html 會退化成一份可捲動的長頁，四份簡報仍可完整閱讀。
- diabolo.html、jump-rope.html、spinning-top.html、shuttlecock.html 仍保留，方便單獨轉寄；這些檔案的「← 四項比賽規則」連結需要和 index.html 放在同一資料夾才會生效。
- 各簡報的「原始 PDF」連結指向 ChatGPT 檔案庫，未登入會回 401，屬正常現象；本機沒有 PDF 備份，核對原文時請先登入。
